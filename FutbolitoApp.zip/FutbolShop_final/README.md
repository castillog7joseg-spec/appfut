# FutbolShop

Proyecto Flutter de una tienda de productos de futbol.

## Correccion aplicada

Este proyecto usa una restriccion de Dart compatible con Dart 3.12.2:

sdk: ">=3.12.0 <4.0.0"

Tambien usa una version de `flutter_lints` compatible con esa base y no necesita paquetes externos para funcionar.

## Funcionalidades

- Splash inicial.
- 3 banners en la pantalla de inicio que se despliegan al tocarlos y muestran los productos de cada promo.
- Categorias que filtran los productos al tocarlas.
- Productos destacados.
- Busqueda.
- Detalle de producto.
- Favoritos.
- Carrito con cantidades.
- Eliminacion/reduccion de productos del carrito.
- Total de compra.
- Seleccion de metodo de pago.
- Confirmacion de compra.
- Historial de compras.
- Perfil.
- Navegacion inferior.
- Contador de favoritos y carrito.

## Como ejecutar

Abrir la carpeta `FutbolShop` en VS Code y ejecutar:

flutter clean
flutter pub get
flutter run

Si Windows pide elegir un dispositivo, usar Chrome, Edge o un emulador/dispositivo conectado.

Las fotos de los productos y banners son fotos reales de Unsplash (gratuitas) y se cargan desde Internet. Si no hay conexion, cada producto muestra un dibujo de reemplazo, asi nunca queda vacio.
