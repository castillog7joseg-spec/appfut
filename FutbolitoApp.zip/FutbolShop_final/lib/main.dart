import 'dart:math' as math;

import 'package:flutter/material.dart';

void main() {
  runApp(const FutbolShopApp());
}

// Claves globales para poder mostrar mensajes y dialogos
// desde cualquier parte de la app.
final messengerKey = GlobalKey<ScaffoldMessengerState>();
final navigatorKey = GlobalKey<NavigatorState>();

// Tipo de dibujo que representa a cada producto.
enum ArtKind {
  jerseyArgentina,
  jerseyClub,
  boot,
  ball,
  tracksuit,
  gloves,
  socks,
  shorts,
}

class Product {
  final String id;
  final String name;
  final String category;
  final double price;
  final String image;
  final ArtKind art;
  final Color color;
  final String description;

  const Product({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
    required this.image,
    required this.art,
    required this.color,
    required this.description,
  });
}

const products = <Product>[
  Product(
    id: 'p1',
    name: 'Camiseta Argentina',
    category: 'Camisetas',
    price: 45999,
    image: '1718337799103-f1080ce21ba6',
    art: ArtKind.jerseyArgentina,
    color: Color(0xffcfe5f7),
    description: 'Camiseta de futbol de excelente calidad, ideal para entrenar, jugar y alentar.',
  ),
  Product(
    id: 'p2',
    name: 'Botines Pro X',
    category: 'Botines',
    price: 74999,
    image: '1451256656121-9ffc0c898a49',
    art: ArtKind.boot,
    color: Color(0xfffde2c6),
    description: 'Botines livianos con buena sujecion y agarre para partidos y entrenamientos.',
  ),
  Product(
    id: 'p3',
    name: 'Pelota Match',
    category: 'Pelotas',
    price: 38999,
    image: '1575361204480-aadea25e6e68',
    art: ArtKind.ball,
    color: Color(0xffd3efd8),
    description: 'Pelota para entrenamiento y partidos, con superficie resistente.',
  ),
  Product(
    id: 'p4',
    name: 'Conjunto Training',
    category: 'Indumentaria',
    price: 52999,
    image: '1760736699270-d1bc09a6509f',
    art: ArtKind.tracksuit,
    color: Color(0xffdde1f2),
    description: 'Conjunto deportivo comodo para entrenar durante toda la temporada.',
  ),
  Product(
    id: 'p5',
    name: 'Guantes de Arquero',
    category: 'Arquero',
    price: 41999,
    image: '1632072820781-79f3a064f640',
    art: ArtKind.gloves,
    color: Color(0xffe9f6cf),
    description: 'Guantes con buen agarre y proteccion para entrenamientos y partidos.',
  ),
  Product(
    id: 'p6',
    name: 'Medias Pro',
    category: 'Accesorios',
    price: 12999,
    image: '1787749202208-c7d733fd305d',
    art: ArtKind.socks,
    color: Color(0xffd9e8fa),
    description: 'Medias deportivas comodas para completar tu equipamiento.',
  ),
  Product(
    id: 'p7',
    name: 'Camiseta Club',
    category: 'Camisetas',
    price: 42999,
    image: '1616124619460-ff4ed8f4683c',
    art: ArtKind.jerseyClub,
    color: Color(0xfff8d9d9),
    description: 'Camiseta deportiva de club con diseño moderno.',
  ),
  Product(
    id: 'p8',
    name: 'Short Futbol',
    category: 'Indumentaria',
    price: 23999,
    image: '1718337855578-d2b52e10253d',
    art: ArtKind.shorts,
    color: Color(0xffe4e4e4),
    description: 'Short liviano y comodo para entrenar y jugar.',
  ),
];

String money(double value) {
  return '\$${value.toStringAsFixed(0).replaceAllMapped(
        RegExp(r'(\d)(?=(\d{3})+(?!\d))'),
        (m) => '${m[1]}.',
      )}';
}

// Arma la direccion de la foto en Unsplash (fotos gratuitas).
String photoUrl(String id, {int width = 700}) =>
    'https://images.unsplash.com/photo-$id?auto=format&fit=crop&w=$width&q=80';

void openProduct(
  BuildContext context,
  Product product, {
  required bool isFavorite,
  required VoidCallback onFavorite,
  required VoidCallback onAdd,
}) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => ProductDetailPage(
        product: product,
        isFavorite: isFavorite,
        onFavorite: onFavorite,
        onAdd: onAdd,
      ),
    ),
  );
}

class FutbolShopApp extends StatefulWidget {
  const FutbolShopApp({super.key});

  @override
  State<FutbolShopApp> createState() => _FutbolShopAppState();
}

class _FutbolShopAppState extends State<FutbolShopApp> {
  int tab = 0;
  final Set<String> favorites = {};
  final Map<String, int> cart = {};
  final List<String> purchases = [];

  void toggleFavorite(String id) {
    setState(() {
      if (favorites.contains(id)) {
        favorites.remove(id);
      } else {
        favorites.add(id);
      }
    });
  }

  void addToCart(Product product) {
    setState(() {
      cart[product.id] = (cart[product.id] ?? 0) + 1;
    });
    messengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text('${product.name} agregado al carrito'),
          duration: const Duration(seconds: 1),
        ),
      );
  }

  void removeFromCart(String id) {
    setState(() {
      final quantity = cart[id] ?? 0;
      if (quantity <= 1) {
        cart.remove(id);
      } else {
        cart[id] = quantity - 1;
      }
    });
  }

  int get cartCount => cart.values.fold(0, (a, b) => a + b);

  double get cartTotal {
    double total = 0;
    for (final entry in cart.entries) {
      final product = products.firstWhere((p) => p.id == entry.key);
      total += product.price * entry.value;
    }
    return total;
  }

  void buyCart() {
    if (cart.isEmpty) return;
    final now = DateTime.now();
    setState(() {
      purchases.add(
        '${now.day.toString().padLeft(2, '0')}/'
        '${now.month.toString().padLeft(2, '0')}/'
        '${now.year} - ${money(cartTotal)}',
      );
      cart.clear();
    });
    final dialogContext = navigatorKey.currentContext;
    if (dialogContext == null) return;
    showDialog(
      context: dialogContext,
      builder: (context) => AlertDialog(
        title: const Text('Compra confirmada'),
        content: const Text(
          'Tu compra fue registrada correctamente. Gracias por elegir FutbolShop.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Aceptar'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FutbolShop',
      scaffoldMessengerKey: messengerKey,
      navigatorKey: navigatorKey,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        scaffoldBackgroundColor: const Color(0xfff5f7f5),
        appBarTheme: const AppBarTheme(centerTitle: false),
      ),
      home: SplashPage(
        child: MainShell(
          selectedIndex: tab,
          onTabChanged: (index) => setState(() => tab = index),
          products: products,
          favorites: favorites,
          cart: cart,
          cartCount: cartCount,
          cartTotal: cartTotal,
          purchases: purchases,
          onFavorite: toggleFavorite,
          onAdd: addToCart,
          onRemove: removeFromCart,
          onBuy: buyCart,
        ),
      ),
    );
  }
}

class SplashPage extends StatefulWidget {
  final Widget child;
  const SplashPage({super.key, required this.child});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  bool showApp = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1300), () {
      if (mounted) setState(() => showApp = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (showApp) return widget.child;
    return const Scaffold(
      backgroundColor: Color(0xff0b6b38),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.sports_soccer, color: Colors.white, size: 92),
            SizedBox(height: 16),
            Text(
              'FUTBOLSHOP',
              style: TextStyle(
                color: Colors.white,
                fontSize: 30,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Todo para tu futbol',
              style: TextStyle(color: Colors.white70, fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}

class MainShell extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onTabChanged;
  final List<Product> products;
  final Set<String> favorites;
  final Map<String, int> cart;
  final int cartCount;
  final double cartTotal;
  final List<String> purchases;
  final void Function(String) onFavorite;
  final void Function(Product) onAdd;
  final void Function(String) onRemove;
  final VoidCallback onBuy;

  const MainShell({
    super.key,
    required this.selectedIndex,
    required this.onTabChanged,
    required this.products,
    required this.favorites,
    required this.cart,
    required this.cartCount,
    required this.cartTotal,
    required this.purchases,
    required this.onFavorite,
    required this.onAdd,
    required this.onRemove,
    required this.onBuy,
  });

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(
        products: products,
        favorites: favorites,
        onFavorite: onFavorite,
        onAdd: onAdd,
      ),
      SearchPage(
        products: products,
        favorites: favorites,
        onFavorite: onFavorite,
        onAdd: onAdd,
      ),
      FavoritesPage(
        products: products.where((p) => favorites.contains(p.id)).toList(),
        favorites: favorites,
        onFavorite: onFavorite,
        onAdd: onAdd,
      ),
      CartPage(
        products: products,
        cart: cart,
        total: cartTotal,
        onAdd: onAdd,
        onRemove: onRemove,
        onBuy: onBuy,
      ),
      ProfilePage(purchases: purchases),
    ];

    return Scaffold(
      body: IndexedStack(index: selectedIndex, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: onTabChanged,
        destinations: [
          const NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Inicio',
          ),
          const NavigationDestination(
            icon: Icon(Icons.search),
            label: 'Buscar',
          ),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: favorites.isNotEmpty,
              label: Text('${favorites.length}'),
              child: const Icon(Icons.favorite_border),
            ),
            selectedIcon: const Icon(Icons.favorite),
            label: 'Favoritos',
          ),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: cartCount > 0,
              label: Text('$cartCount'),
              child: const Icon(Icons.shopping_cart_outlined),
            ),
            selectedIcon: const Icon(Icons.shopping_cart),
            label: 'Carrito',
          ),
          const NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Perfil',
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final List<Product> products;
  final Set<String> favorites;
  final void Function(String) onFavorite;
  final void Function(Product) onAdd;

  const HomePage({
    super.key,
    required this.products,
    required this.favorites,
    required this.onFavorite,
    required this.onAdd,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // Categoria elegida. null = se muestran todos los productos.
  String? category;

  static const categories = <(String, IconData)>[
    ('Todos', Icons.apps),
    ('Camisetas', Icons.checkroom),
    ('Botines', Icons.directions_run),
    ('Pelotas', Icons.sports_soccer),
    ('Indumentaria', Icons.dry_cleaning),
    ('Arquero', Icons.back_hand),
    ('Accesorios', Icons.shopping_bag),
  ];

  List<Product> _byIds(List<String> ids) =>
      widget.products.where((p) => ids.contains(p.id)).toList();

  @override
  Widget build(BuildContext context) {
    final favorites = widget.favorites;
    final onFavorite = widget.onFavorite;
    final onAdd = widget.onAdd;
    final shown = category == null
        ? widget.products
        : widget.products.where((p) => p.category == category).toList();

    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            title: const Text(
              'FutbolShop',
              style: TextStyle(fontWeight: FontWeight.w900),
            ),
            actions: [
              IconButton(
                onPressed: () async {
                  final p = await showSearch<Product?>(
                    context: context,
                    delegate: ProductSearchDelegate(widget.products),
                  );
                  if (p != null && context.mounted) {
                    openProduct(
                      context,
                      p,
                      isFavorite: favorites.contains(p.id),
                      onFavorite: () => onFavorite(p.id),
                      onAdd: () => onAdd(p),
                    );
                  }
                },
                icon: const Icon(Icons.search),
              ),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
              child: Column(
                children: [
                  PromoBanner(
                    title: 'PASION POR EL FUTBOL',
                    subtitle: 'Todo lo que necesitas para jugar',
                    description:
                        'Las camisetas mas elegidas y la pelota para '
                        'tus partidos. Toca un producto para ver el detalle.',
                    image: '1574629810360-7efbbe195018',
                    colors: const [Color(0xff0b6b38), Color(0xff1fa35a)],
                    products: _byIds(['p1', 'p7', 'p3']),
                    favorites: favorites,
                    onFavorite: onFavorite,
                    onAdd: onAdd,
                  ),
                  const SizedBox(height: 10),
                  PromoBanner(
                    title: 'EQUIPATE PARA GANAR',
                    subtitle: 'Botines y accesorios seleccionados',
                    description:
                        'Botines con agarre, guantes para el arco y medias '
                        'para completar tu equipo.',
                    image: '1529900748604-07564a03e7a6',
                    colors: const [Color(0xffc2410c), Color(0xfff59e0b)],
                    products: _byIds(['p2', 'p5', 'p6']),
                    favorites: favorites,
                    onFavorite: onFavorite,
                    onAdd: onAdd,
                  ),
                  const SizedBox(height: 10),
                  PromoBanner(
                    title: 'NUEVA TEMPORADA',
                    subtitle: 'Indumentaria para entrenar',
                    description:
                        'Ropa comoda y liviana para entrenar toda la '
                        'temporada.',
                    image: '1760736534441-4d14bf11103e',
                    colors: const [Color(0xff1f2a5c), Color(0xff3b5bdb)],
                    products: _byIds(['p4', 'p8']),
                    favorites: favorites,
                    onFavorite: onFavorite,
                    onAdd: onAdd,
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
              child: Text(
                'Categorias',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 92,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  for (final (name, icon) in categories)
                    CategoryChip(
                      icon: icon,
                      text: name,
                      selected: name == 'Todos'
                          ? category == null
                          : category == name,
                      onTap: () => setState(() {
                        category = name == 'Todos' ? null : name;
                      }),
                    ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      category ?? 'Productos destacados',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w800,
                          ),
                    ),
                  ),
                  if (category != null)
                    TextButton(
                      onPressed: () => setState(() => category = null),
                      child: const Text('Ver todos'),
                    ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final product = shown[index];
                  return ProductCard(
                    product: product,
                    isFavorite: favorites.contains(product.id),
                    onFavorite: () => onFavorite(product.id),
                    onAdd: () => onAdd(product),
                  );
                },
                childCount: shown.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: .66,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Banner que se despliega al tocarlo y muestra los productos de la promo.
class PromoBanner extends StatefulWidget {
  final String title;
  final String subtitle;
  final String description;
  final String image;
  final List<Color> colors;
  final List<Product> products;
  final Set<String> favorites;
  final void Function(String) onFavorite;
  final void Function(Product) onAdd;

  const PromoBanner({
    super.key,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.image,
    required this.colors,
    required this.products,
    required this.favorites,
    required this.onFavorite,
    required this.onAdd,
  });

  @override
  State<PromoBanner> createState() => _PromoBannerState();
}

class _PromoBannerState extends State<PromoBanner> {
  bool expanded = false;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      elevation: expanded ? 3 : 0,
      borderRadius: BorderRadius.circular(20),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          InkWell(
            onTap: () => setState(() => expanded = !expanded),
            child: SizedBox(
              height: 150,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: widget.colors,
                      ),
                    ),
                  ),
                  // Foto real del banner
                  Image.network(
                    photoUrl(widget.image, width: 1200),
                    fit: BoxFit.cover,
                    errorBuilder: (_, _, _) =>
                        const CustomPaint(painter: FieldPainter()),
                  ),
                  // Oscurece la foto para que se lea el texto
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [Color(0xcc000000), Color(0x22000000)],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: .22),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                expanded ? 'Ocultar' : 'Ver productos',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              AnimatedRotation(
                                turns: expanded ? .5 : 0,
                                duration: const Duration(milliseconds: 250),
                                child: const Icon(
                                  Icons.keyboard_arrow_down,
                                  color: Colors.white,
                                  size: 18,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Spacer(),
                        Text(
                          widget.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            height: 1.05,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          widget.subtitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 300),
            sizeCurve: Curves.easeInOut,
            crossFadeState:
                expanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
            firstChild: const SizedBox(width: double.infinity),
            secondChild: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.description,
                    style: TextStyle(color: Colors.grey.shade800),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 200,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: widget.products.length,
                      separatorBuilder: (_, _) => const SizedBox(width: 10),
                      itemBuilder: (context, index) {
                        final p = widget.products[index];
                        return MiniProductCard(
                          product: p,
                          onTap: () => openProduct(
                            context,
                            p,
                            isFavorite: widget.favorites.contains(p.id),
                            onFavorite: () => widget.onFavorite(p.id),
                            onAdd: () => widget.onAdd(p),
                          ),
                          onAdd: () => widget.onAdd(p),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class MiniProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback onTap;
  final VoidCallback onAdd;

  const MiniProductCard({
    super.key,
    required this.product,
    required this.onTap,
    required this.onAdd,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 140,
      child: Card(
        margin: EdgeInsets.zero,
        clipBehavior: Clip.antiAlias,
        elevation: 0,
        color: const Color(0xfff3f5f3),
        child: InkWell(
          onTap: onTap,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: ProductPhoto(product: product),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                child: Text(
                  product.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 13,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 0, 2, 2),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        money(product.price),
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: onAdd,
                      icon: const Icon(Icons.add_shopping_cart, size: 20),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CategoryChip extends StatelessWidget {
  final IconData icon;
  final String text;
  final bool selected;
  final VoidCallback onTap;

  const CategoryChip({
    super.key,
    required this.icon,
    required this.text,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final green = Colors.green.shade700;
    return Container(
      width: 104,
      margin: const EdgeInsets.only(right: 10),
      child: Card(
        elevation: 0,
        clipBehavior: Clip.antiAlias,
        color: selected ? green : null,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: selected ? Colors.white : green),
                const SizedBox(height: 5),
                Text(
                  text,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: selected ? Colors.white : null,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ProductCard extends StatelessWidget {
  final Product product;
  final bool isFavorite;
  final VoidCallback onFavorite;
  final VoidCallback onAdd;

  const ProductCard({
    super.key,
    required this.product,
    required this.isFavorite,
    required this.onFavorite,
    required this.onAdd,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      elevation: 1,
      child: InkWell(
        onTap: () => openProduct(
          context,
          product,
          isFavorite: isFavorite,
          onFavorite: onFavorite,
          onAdd: onAdd,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                children: [
                  Positioned.fill(
                    child: ProductPhoto(product: product),
                  ),
                  Positioned(
                    top: 7,
                    right: 7,
                    child: Material(
                      color: Colors.white.withValues(alpha: .9),
                      shape: const CircleBorder(),
                      child: IconButton(
                        visualDensity: VisualDensity.compact,
                        onPressed: onFavorite,
                        icon: Icon(
                          isFavorite ? Icons.favorite : Icons.favorite_border,
                          color: isFavorite ? Colors.red : Colors.black87,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
              child: Text(
                product.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 4, 10, 0),
              child: Text(
                product.category,
                style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 5, 10, 8),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      money(product.price),
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    onPressed: onAdd,
                    icon: const Icon(Icons.add_shopping_cart),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ProductDetailPage extends StatefulWidget {
  final Product product;
  final bool isFavorite;
  final VoidCallback onFavorite;
  final VoidCallback onAdd;

  const ProductDetailPage({
    super.key,
    required this.product,
    required this.isFavorite,
    required this.onFavorite,
    required this.onAdd,
  });

  @override
  State<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  late bool isFavorite = widget.isFavorite;

  @override
  Widget build(BuildContext context) {
    final product = widget.product;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalle del producto'),
        actions: [
          IconButton(
            onPressed: () {
              widget.onFavorite();
              setState(() => isFavorite = !isFavorite);
            },
            icon: Icon(
              isFavorite ? Icons.favorite : Icons.favorite_border,
              color: isFavorite ? Colors.red : null,
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 30),
        children: [
          SizedBox(
            height: 330,
            child: ProductPhoto(product: product, width: 1000),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product.category.toUpperCase(),
                  style: TextStyle(
                    color: Colors.green.shade700,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  product.name,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
                const SizedBox(height: 10),
                Text(
                  money(product.price),
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
                const SizedBox(height: 18),
                Text(
                  product.description,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: FilledButton.icon(
                    onPressed: () {
                      widget.onAdd();
                      Navigator.pop(context);
                    },
                    icon: const Icon(Icons.shopping_cart),
                    label: const Text('Agregar al carrito'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SearchPage extends StatefulWidget {
  final List<Product> products;
  final Set<String> favorites;
  final void Function(String) onFavorite;
  final void Function(Product) onAdd;

  const SearchPage({
    super.key,
    required this.products,
    required this.favorites,
    required this.onFavorite,
    required this.onAdd,
  });

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final controller = TextEditingController();
  String query = '';

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = widget.products.where((p) {
      final q = query.toLowerCase().trim();
      return q.isEmpty ||
          p.name.toLowerCase().contains(q) ||
          p.category.toLowerCase().contains(q);
    }).toList();

    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
            child: TextField(
              controller: controller,
              autofocus: false,
              onChanged: (value) => setState(() => query = value),
              decoration: InputDecoration(
                hintText: 'Buscar productos...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: query.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          controller.clear();
                          setState(() => query = '');
                        },
                        icon: const Icon(Icons.clear),
                      ),
                filled: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Expanded(
            child: filtered.isEmpty
                ? const Center(child: Text('No se encontraron productos'))
                : GridView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                    itemCount: filtered.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: .66,
                    ),
                    itemBuilder: (_, index) {
                      final p = filtered[index];
                      return ProductCard(
                        product: p,
                        isFavorite: widget.favorites.contains(p.id),
                        onFavorite: () => widget.onFavorite(p.id),
                        onAdd: () => widget.onAdd(p),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class FavoritesPage extends StatelessWidget {
  final List<Product> products;
  final Set<String> favorites;
  final void Function(String) onFavorite;
  final void Function(Product) onAdd;

  const FavoritesPage({
    super.key,
    required this.products,
    required this.favorites,
    required this.onFavorite,
    required this.onAdd,
  });

  @override
  Widget build(BuildContext context) {
    if (products.isEmpty) {
      return const SafeArea(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.favorite_border, size: 70, color: Colors.grey),
              SizedBox(height: 12),
              Text('Todavia no tienes favoritos'),
            ],
          ),
        ),
      );
    }

    return SafeArea(
      child: GridView.builder(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
        itemCount: products.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: .66,
        ),
        itemBuilder: (_, index) {
          final p = products[index];
          return ProductCard(
            product: p,
            isFavorite: favorites.contains(p.id),
            onFavorite: () => onFavorite(p.id),
            onAdd: () => onAdd(p),
          );
        },
      ),
    );
  }
}

class CartPage extends StatelessWidget {
  final List<Product> products;
  final Map<String, int> cart;
  final double total;
  final void Function(Product) onAdd;
  final void Function(String) onRemove;
  final VoidCallback onBuy;

  const CartPage({
    super.key,
    required this.products,
    required this.cart,
    required this.total,
    required this.onAdd,
    required this.onRemove,
    required this.onBuy,
  });

  @override
  Widget build(BuildContext context) {
    final entries = cart.entries.toList();

    if (entries.isEmpty) {
      return const SafeArea(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.shopping_cart_outlined, size: 80, color: Colors.grey),
              SizedBox(height: 12),
              Text('Tu carrito esta vacio'),
            ],
          ),
        ),
      );
    }

    return SafeArea(
      child: Column(
        children: [
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: entries.length,
              separatorBuilder: (_, _) => const SizedBox(height: 10),
              itemBuilder: (_, index) {
                final entry = entries[index];
                final product = products.firstWhere((p) => p.id == entry.key);
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: SizedBox(
                            width: 85,
                            height: 85,
                            child: ProductPhoto(product: product),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                product.name,
                                style: const TextStyle(fontWeight: FontWeight.w800),
                              ),
                              const SizedBox(height: 4),
                              Text(money(product.price)),
                              const SizedBox(height: 7),
                              Row(
                                children: [
                                  IconButton(
                                    visualDensity: VisualDensity.compact,
                                    onPressed: () => onRemove(product.id),
                                    icon: const Icon(Icons.remove_circle_outline),
                                  ),
                                  Text('${entry.value}'),
                                  IconButton(
                                    visualDensity: VisualDensity.compact,
                                    onPressed: () => onAdd(product),
                                    icon: const Icon(Icons.add_circle_outline),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 18),
            decoration: const BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(blurRadius: 12, color: Colors.black12)],
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Total', style: TextStyle(fontSize: 18)),
                    Text(
                      money(total),
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: FilledButton(
                    onPressed: () => _checkout(context),
                    child: const Text('Comprar ahora'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _checkout(BuildContext context) {
    const options = {
      'Mercado Pago': 'Mercado Pago',
      'Tarjeta': 'Tarjeta de credito/debito',
      'Efectivo': 'Efectivo',
    };
    String payment = 'Mercado Pago';
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(
        builder: (context, setSheetState) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Metodo de pago',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 6),
              for (final option in options.entries)
                ListTile(
                  leading: Icon(
                    payment == option.key
                        ? Icons.radio_button_checked
                        : Icons.radio_button_unchecked,
                    color: payment == option.key
                        ? Theme.of(context).colorScheme.primary
                        : null,
                  ),
                  title: Text(option.value),
                  onTap: () => setSheetState(() => payment = option.key),
                ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () {
                    Navigator.pop(context);
                    onBuy();
                  },
                  child: Text('Confirmar con $payment'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  final List<String> purchases;

  const ProfilePage({super.key, required this.purchases});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const SizedBox(height: 10),
          const CircleAvatar(
            radius: 42,
            child: Icon(Icons.person, size: 48),
          ),
          const SizedBox(height: 12),
          const Center(
            child: Text(
              'Mi perfil',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
            ),
          ),
          const SizedBox(height: 20),
          Card(
            child: Column(
              children: [
                const ListTile(
                  leading: Icon(Icons.person_outline),
                  title: Text('Usuario'),
                  subtitle: Text('Cliente FutbolShop'),
                ),
                const ListTile(
                  leading: Icon(Icons.email_outlined),
                  title: Text('Correo'),
                  subtitle: Text('cliente@futbolshop.com'),
                ),
                ListTile(
                  leading: const Icon(Icons.receipt_long_outlined),
                  title: const Text('Historial de compras'),
                  subtitle: Text('${purchases.length} compra(s) registrada(s)'),
                  onTap: () => _showHistory(context),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showHistory(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Historial de compras'),
        content: SizedBox(
          width: 330,
          child: purchases.isEmpty
              ? const Text('Todavia no realizaste compras.')
              : ListView.builder(
                  shrinkWrap: true,
                  itemCount: purchases.length,
                  itemBuilder: (_, index) => ListTile(
                    leading: const Icon(Icons.check_circle, color: Colors.green),
                    title: Text('Compra ${index + 1}'),
                    subtitle: Text(purchases[index]),
                  ),
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cerrar'),
          ),
        ],
      ),
    );
  }
}

class ProductSearchDelegate extends SearchDelegate<Product?> {
  final List<Product> products;

  ProductSearchDelegate(this.products);

  @override
  List<Widget>? buildActions(BuildContext context) => [
        if (query.isNotEmpty)
          IconButton(
            onPressed: () => query = '',
            icon: const Icon(Icons.clear),
          ),
      ];

  @override
  Widget? buildLeading(BuildContext context) => IconButton(
        onPressed: () => close(context, null),
        icon: const Icon(Icons.arrow_back),
      );

  @override
  Widget buildResults(BuildContext context) {
    final results = products.where((p) {
      final q = query.toLowerCase();
      return p.name.toLowerCase().contains(q) ||
          p.category.toLowerCase().contains(q);
    }).toList();

    return ListView.builder(
      itemCount: results.length,
      itemBuilder: (_, index) {
        final p = results[index];
        return ListTile(
          leading: ClipOval(
            child: SizedBox(
              width: 46,
              height: 46,
              child: ProductPhoto(product: p, width: 200),
            ),
          ),
          title: Text(p.name),
          subtitle: Text('${p.category} - ${money(p.price)}'),
          onTap: () => close(context, p),
        );
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) => buildResults(context);
}

// ===================================================================
// IMAGENES DE LOS PRODUCTOS
// Cada producto se dibuja con codigo, asi la imagen siempre coincide
// con lo que se vende y no hace falta conexion a Internet.
// ===================================================================

// Foto real del producto. Mientras carga, o si no hay Internet,
// muestra el dibujo del producto para que nunca quede vacio.
class ProductPhoto extends StatelessWidget {
  final Product product;
  final int width;

  const ProductPhoto({super.key, required this.product, this.width = 600});

  @override
  Widget build(BuildContext context) {
    final fallback = ProductArt(
      kind: product.art,
      background: product.color,
      padding: 12,
    );
    return Image.network(
      photoUrl(product.image, width: width),
      fit: BoxFit.cover,
      width: double.infinity,
      height: double.infinity,
      loadingBuilder: (context, child, progress) =>
          progress == null ? child : fallback,
      errorBuilder: (_, _, _) => fallback,
    );
  }
}

class ProductArt extends StatelessWidget {
  final ArtKind kind;
  final Color background;
  final double padding;

  const ProductArt({
    super.key,
    required this.kind,
    required this.background,
    this.padding = 16,
  });

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color.lerp(background, Colors.white, .6)!, background],
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(padding),
        child: CustomPaint(
          painter: ArtPainter(kind),
          child: const SizedBox.expand(),
        ),
      ),
    );
  }
}

// Dibuja lineas de cancha de futbol en el fondo de los banners.
class FieldPainter extends CustomPainter {
  const FieldPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = Colors.white.withValues(alpha: .13)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    final midX = size.width * .62;
    canvas.drawLine(Offset(midX, 0), Offset(midX, size.height), p);
    canvas.drawCircle(Offset(midX, size.height / 2), size.height * .32, p);
    canvas.drawCircle(
      Offset(midX, size.height / 2),
      3,
      p..style = PaintingStyle.fill,
    );
  }

  @override
  bool shouldRepaint(FieldPainter oldDelegate) => false;
}

class ArtPainter extends CustomPainter {
  final ArtKind kind;
  const ArtPainter(this.kind);

  static const _outline = Color(0x40000000);

  Paint _fill(Color c) => Paint()..color = c;

  Paint _line(Color c, double w) => Paint()
    ..color = c
    ..style = PaintingStyle.stroke
    ..strokeWidth = w
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round;

  @override
  void paint(Canvas canvas, Size size) {
    // Todo se dibuja en una grilla de 100 x 100 centrada.
    final s = math.min(size.width, size.height);
    canvas.save();
    canvas.translate((size.width - s) / 2, (size.height - s) / 2);
    canvas.scale(s / 100);

    // Sombra en el piso
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(50, 95), width: 62, height: 7),
      _fill(Colors.black.withValues(alpha: .12)),
    );

    switch (kind) {
      case ArtKind.jerseyArgentina:
        _jersey(
          canvas,
          base: Colors.white,
          stripe: const Color(0xff74acdf),
          sleeve: null,
          trim: const Color(0xff1b2a4a),
          number: '10',
          numberColor: const Color(0xff1b2a4a),
        );
      case ArtKind.jerseyClub:
        _jersey(
          canvas,
          base: const Color(0xffd32f2f),
          stripe: null,
          sleeve: Colors.white,
          trim: Colors.white,
          number: '9',
          numberColor: Colors.white,
        );
      case ArtKind.boot:
        _boot(canvas);
      case ArtKind.ball:
        _ball(canvas);
      case ArtKind.tracksuit:
        _tracksuit(canvas);
      case ArtKind.gloves:
        _gloves(canvas);
      case ArtKind.socks:
        _socks(canvas);
      case ArtKind.shorts:
        _shorts(canvas);
    }

    canvas.restore();
  }

  void _text(Canvas c, String t, Offset center, double size, Color color) {
    final tp = TextPainter(
      text: TextSpan(
        text: t,
        style: TextStyle(
          fontSize: size,
          fontWeight: FontWeight.w900,
          color: color,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(c, center - Offset(tp.width / 2, tp.height / 2));
  }

  // ---------- Camiseta ----------
  void _jersey(
    Canvas c, {
    required Color base,
    required Color? stripe,
    required Color? sleeve,
    required Color trim,
    required String number,
    required Color numberColor,
  }) {
    final body = Path()
      ..moveTo(36, 10)
      ..quadraticBezierTo(50, 20, 64, 10)
      ..lineTo(82, 16)
      ..lineTo(97, 36)
      ..lineTo(85, 47)
      ..lineTo(78, 40)
      ..lineTo(78, 88)
      ..quadraticBezierTo(50, 92, 22, 88)
      ..lineTo(22, 40)
      ..lineTo(15, 47)
      ..lineTo(3, 36)
      ..lineTo(18, 16)
      ..close();

    c.drawPath(body, _fill(base));
    c.save();
    c.clipPath(body);
    if (stripe != null) {
      for (final x in [27.0, 45.0, 63.0]) {
        c.drawRect(Rect.fromLTWH(x, 0, 10, 100), _fill(stripe));
      }
    }
    if (sleeve != null) {
      c.drawRect(const Rect.fromLTWH(0, 0, 22, 100), _fill(sleeve));
      c.drawRect(const Rect.fromLTWH(78, 0, 22, 100), _fill(sleeve));
    }
    // Punos de las mangas
    c.drawLine(const Offset(95, 33), const Offset(83, 45), _line(trim, 5));
    c.drawLine(const Offset(5, 33), const Offset(17, 45), _line(trim, 5));
    // Sombra suave del lado derecho
    c.drawRect(
      const Rect.fromLTWH(64, 0, 40, 100),
      _fill(Colors.black.withValues(alpha: .05)),
    );
    c.restore();

    // Cuello
    c.drawPath(
      Path()
        ..moveTo(36, 10)
        ..quadraticBezierTo(50, 22, 64, 10),
      _line(trim, 4),
    );
    c.drawPath(body, _line(_outline, 1.2));
    _text(c, number, const Offset(50, 54), 24, numberColor);
  }

  // ---------- Botin ----------
  void _boot(Canvas c) {
    const upperColor = Color(0xffff6d1f);
    const accent = Color(0xff222831);
    const sole = Color(0xff2b2b2b);

    c.save();
    c.translate(0, 6);
    final upper = Path()
      ..moveTo(12, 34)
      ..quadraticBezierTo(22, 29, 34, 33)
      ..quadraticBezierTo(42, 44, 54, 44)
      ..lineTo(76, 50)
      ..quadraticBezierTo(95, 54, 93, 66)
      ..lineTo(10, 66)
      ..quadraticBezierTo(6, 50, 12, 34)
      ..close();

    c.drawPath(upper, _fill(upperColor));
    c.save();
    c.clipPath(upper);
    // Franja decorativa
    final sweep = Path()
      ..moveTo(18, 60)
      ..quadraticBezierTo(50, 38, 94, 56)
      ..lineTo(94, 63)
      ..quadraticBezierTo(50, 48, 18, 66)
      ..close();
    c.drawPath(sweep, _fill(accent));
    // Talon
    c.drawRect(
      const Rect.fromLTWH(0, 0, 20, 100),
      _fill(Colors.black.withValues(alpha: .14)),
    );
    c.restore();
    c.drawPath(upper, _line(_outline, 1.2));

    // Cordones
    for (final p in const [
      Offset(43, 43),
      Offset(51, 45.5),
      Offset(59, 47.5),
      Offset(67, 49.5),
    ]) {
      c.drawLine(
        p + const Offset(-2.5, -1),
        p + const Offset(2.5, 3),
        _line(Colors.white, 2),
      );
    }

    // Suela y tapones
    c.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTRB(8, 66, 95, 72),
        const Radius.circular(3),
      ),
      _fill(sole),
    );
    for (final x in const [15.0, 27.0, 55.0, 67.0, 79.0]) {
      c.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, 71, 6, 7),
          const Radius.circular(1.5),
        ),
        _fill(sole),
      );
    }
    c.restore();
  }

  // ---------- Pelota ----------
  void _ball(Canvas c) {
    const center = Offset(50, 48);
    const r = 40.0;
    final rect = Rect.fromCircle(center: center, radius: r);
    final dark = _fill(const Color(0xff1f2329));
    final seam = _line(const Color(0xff1f2329), 1.6);

    Path pentagon(Offset o, double rad, double rot) {
      final p = Path();
      for (var i = 0; i < 5; i++) {
        final a = rot + i * 2 * math.pi / 5;
        final pt = o + Offset(math.cos(a) * rad, math.sin(a) * rad);
        if (i == 0) {
          p.moveTo(pt.dx, pt.dy);
        } else {
          p.lineTo(pt.dx, pt.dy);
        }
      }
      return p..close();
    }

    c.drawCircle(center, r, _fill(Colors.white));
    c.save();
    c.clipPath(Path()..addOval(rect));

    c.drawPath(pentagon(center, 13, -math.pi / 2), dark);
    for (var i = 0; i < 5; i++) {
      final a = -math.pi / 2 + i * 2 * math.pi / 5;
      final dir = Offset(math.cos(a), math.sin(a));
      // Costura desde el pentagono central hacia afuera
      c.drawLine(center + dir * 13, center + dir * 26, seam);
      // Pentagonos del borde
      c.drawPath(pentagon(center + dir * 39, 13, a + math.pi), dark);
      // Costuras entre los pentagonos del borde
      final b = a + math.pi / 5;
      final dirB = Offset(math.cos(b), math.sin(b));
      c.drawLine(center + dirB * 30, center + dirB * 44, seam);
    }
    // Brillo y sombra para dar volumen
    c.drawRect(
      rect,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-.35, -.4),
          radius: .95,
          colors: [Color(0x00000000), Color(0x33000000)],
        ).createShader(rect),
    );
    c.restore();
    c.drawCircle(center, r, _line(_outline, 1.2));
  }

  // ---------- Conjunto (campera deportiva) ----------
  void _tracksuit(Canvas c) {
    const navy = Color(0xff1f2a5c);
    const accent = Color(0xff2ecc71);

    final jacket = Path()
      ..moveTo(36, 12)
      ..quadraticBezierTo(50, 20, 64, 12)
      ..lineTo(80, 17)
      ..lineTo(95, 80)
      ..lineTo(84, 82)
      ..lineTo(76, 46)
      ..lineTo(76, 90)
      ..lineTo(24, 90)
      ..lineTo(24, 46)
      ..lineTo(16, 82)
      ..lineTo(5, 80)
      ..lineTo(20, 17)
      ..close();

    c.drawPath(jacket, _fill(navy));
    c.save();
    c.clipPath(jacket);
    // Franjas en las mangas
    c.drawLine(const Offset(21, 19), const Offset(10, 81), _line(accent, 3.5));
    c.drawLine(const Offset(79, 19), const Offset(90, 81), _line(accent, 3.5));
    // Cintura y punos
    c.drawRect(const Rect.fromLTWH(20, 84, 60, 8), _fill(const Color(0xff141c40)));
    c.drawLine(const Offset(4, 77), const Offset(17, 79), _line(const Color(0xff141c40), 6));
    c.drawLine(const Offset(96, 77), const Offset(83, 79), _line(const Color(0xff141c40), 6));
    c.drawRect(
      const Rect.fromLTWH(62, 0, 40, 100),
      _fill(Colors.black.withValues(alpha: .08)),
    );
    c.restore();

    // Cierre
    c.drawLine(const Offset(50, 18), const Offset(50, 90), _line(const Color(0xffcfd6e6), 1.6));
    c.drawCircle(const Offset(50, 30), 2, _fill(const Color(0xffcfd6e6)));
    // Cuello
    c.drawPath(
      Path()
        ..moveTo(36, 12)
        ..quadraticBezierTo(50, 22, 64, 12),
      _line(accent, 4),
    );
    c.drawPath(jacket, _line(_outline, 1.2));
  }

  // ---------- Guantes de arquero ----------
  void _gloves(Canvas c) {
    _glove(c, const Offset(-14, 4), .82, const Color(0xff3a4250));
    _glove(c, const Offset(12, 0), 1, const Color(0xff222831));
  }

  void _glove(Canvas c, Offset shift, double scale, Color main) {
    const lime = Color(0xffc6ef3c);

    c.save();
    c.translate(50 + shift.dx, 50 + shift.dy);
    c.scale(scale);
    c.translate(-50, -50);

    // Pulgar
    c.save();
    c.translate(31, 64);
    c.rotate(-.75);
    final thumb = RRect.fromRectAndRadius(
      const Rect.fromLTWH(-6, -26, 12, 28),
      const Radius.circular(6),
    );
    c.drawRRect(thumb, _fill(main));
    c.drawRRect(thumb, _line(_outline, 1.2));
    c.restore();

    final palm = RRect.fromRectAndRadius(
      const Rect.fromLTRB(29, 44, 73, 84),
      const Radius.circular(12),
    );
    final fingers = [
      RRect.fromRectAndRadius(const Rect.fromLTWH(30, 22, 10, 36), const Radius.circular(5)),
      RRect.fromRectAndRadius(const Rect.fromLTWH(41, 14, 10, 40), const Radius.circular(5)),
      RRect.fromRectAndRadius(const Rect.fromLTWH(52, 16, 10, 38), const Radius.circular(5)),
      RRect.fromRectAndRadius(const Rect.fromLTWH(63, 25, 10, 32), const Radius.circular(5)),
    ];
    for (final f in fingers) {
      c.drawRRect(f, _fill(main));
      c.drawRRect(f, _line(_outline, 1.2));
    }
    c.drawRRect(palm, _fill(main));
    c.drawRRect(palm, _line(_outline, 1.2));

    // Detalle verde en la mano
    c.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTRB(36, 52, 66, 64),
        const Radius.circular(6),
      ),
      _fill(lime),
    );
    // Muñequera
    final strap = RRect.fromRectAndRadius(
      const Rect.fromLTRB(26, 76, 76, 92),
      const Radius.circular(4),
    );
    c.drawRRect(strap, _fill(lime));
    c.drawLine(const Offset(30, 84), const Offset(72, 84), _line(main, 2));
    c.drawRRect(strap, _line(_outline, 1.2));
    c.restore();
  }

  // ---------- Medias ----------
  void _socks(Canvas c) {
    c.save();
    c.translate(16, -2);
    _sock(c, const Color(0xff0f4c9c));
    c.restore();
    c.save();
    c.translate(-4, 4);
    _sock(c, const Color(0xff1565c0));
    c.restore();
  }

  void _sock(Canvas c, Color color) {
    final sock = Path()
      ..moveTo(30, 8)
      ..lineTo(52, 8)
      ..lineTo(52, 60)
      ..lineTo(70, 71)
      ..quadraticBezierTo(81, 79, 73, 88)
      ..lineTo(42, 88)
      ..quadraticBezierTo(30, 86, 30, 72)
      ..close();

    c.drawPath(sock, _fill(color));
    c.save();
    c.clipPath(sock);
    c.drawRect(const Rect.fromLTWH(0, 8, 100, 6), _fill(const Color(0xff0b2f63)));
    c.drawRect(const Rect.fromLTWH(0, 18, 100, 4), _fill(Colors.white));
    c.drawRect(const Rect.fromLTWH(0, 25, 100, 4), _fill(Colors.white));
    c.drawCircle(const Offset(32, 84), 9, _fill(Colors.white));
    c.drawCircle(const Offset(78, 84), 9, _fill(Colors.white));
    c.restore();
    c.drawPath(sock, _line(_outline, 1.2));
  }

  // ---------- Short ----------
  void _shorts(Canvas c) {
    const base = Color(0xff23262b);
    final shorts = Path()
      ..moveTo(20, 22)
      ..lineTo(80, 22)
      ..lineTo(89, 80)
      ..lineTo(56, 83)
      ..lineTo(50, 50)
      ..lineTo(44, 83)
      ..lineTo(11, 80)
      ..close();

    c.drawPath(shorts, _fill(base));
    c.save();
    c.clipPath(shorts);
    c.drawRect(const Rect.fromLTWH(0, 22, 100, 9), _fill(const Color(0xff15171a)));
    c.drawLine(const Offset(23, 31), const Offset(15, 82), _line(Colors.white, 3));
    c.drawLine(const Offset(77, 31), const Offset(85, 82), _line(Colors.white, 3));
    c.drawRect(
      const Rect.fromLTWH(52, 0, 50, 100),
      _fill(Colors.white.withValues(alpha: .05)),
    );
    c.restore();
    // Cordon de la cintura
    c.drawLine(const Offset(48, 31), const Offset(45, 40), _line(Colors.white, 1.6));
    c.drawLine(const Offset(52, 31), const Offset(55, 40), _line(Colors.white, 1.6));
    c.drawPath(shorts, _line(_outline, 1.2));
  }

  @override
  bool shouldRepaint(ArtPainter oldDelegate) => oldDelegate.kind != kind;
}
